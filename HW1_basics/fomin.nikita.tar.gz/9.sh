#! /bin/bash

date -d '220201' | cut -f 1 -d ' '
