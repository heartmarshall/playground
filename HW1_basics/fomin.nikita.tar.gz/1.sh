#! /bin/bash

mkdir -p task1/biggest_etс task1/smallest_etc

cp `find /etc -type f 2>/dev/null| xargs du -ba 2>/dev/null | sort -nrk 1 | head -n 10| cut -f 2` ./task1/biggest_etс/

cp `find /etc -type f 2>/dev/null| xargs du -ba 2>/dev/null | sort -nk 1 | head -n 10| cut -f 2` ./task1/smallest_etc/

